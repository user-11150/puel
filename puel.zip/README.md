---
author: User-11150
---
# UEL
## 前言
> UEL是一个基于Python的一个解释型语言。
# 让我们开始使用他吧！
```
python setup.py install
python -m uel <filename>
```
## 链接
1. [Gitee](http://gitee.com/user-11150/server)
2. [Contributers](./docs/Contibuters.md)
3. [教学文档](docs/tutorial.md)