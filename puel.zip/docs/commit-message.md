# Usage:
~~~
[<type>] <information>
~~~
1. The `type` is cannot ignore. It only value. It must in (Feature, Bugfix, Document, Code Review) or (F,B,D,C)
2. Please the `Information` must very simple.