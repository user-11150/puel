---

---

## Get start
usage:
```
python -m main <Source>
```

Source =(builder)> `ByteCode`
`ByteCode` =(runner)> execute

---
## What is ByteCode?
  The ByteCode is a PyObject for convenient.
  ==it isn't a file==. It's good for optimize
  
  ---
  Thanks for watching.