# Impprt the classes
from uel.command.SystemArgument import SystemArgument
from uel.core.runner.ExecuteContext import ExecuteContext
from uel.core.runner.task.Wait import Wait as wait
from uel.core.runner.task.BuildTask import BuildTask
from uel.core.runner.task.RunByteCodeFromPyByteObject import RunByteCodeFromPyByteObject

# Import the types
from typing import List
from typing import Final

class Main:
    @staticmethod
    def main(argv: List[str]) -> None:
        # The function will execute build and execute
        
        sa: SystemArgument= SystemArgument(argv)
        sa.parserCommand()
        
        source_file: Final[str] = sa.source_file
        
        pointer = {}
        
        wait(tasks := {
            wait(BuildTask() >> pointer),
            wait(Run() >> pointer)
        })
        
