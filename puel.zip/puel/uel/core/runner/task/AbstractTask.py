class AbstractTask:
    def run(self, *args, **kwargs):
        pass
