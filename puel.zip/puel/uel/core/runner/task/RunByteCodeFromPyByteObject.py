from uel.core.runner.EmptyTask import EmptyTask

class RunByteCodeFromPyByteObject(EmptyTask):
    pass
