"""
No effect
"""

class Wait:
    def __new__(*args,**kwargs):
        pass
