from uel.core.Main import Main
from sys import argv

def main():
    Main().main(argv)
