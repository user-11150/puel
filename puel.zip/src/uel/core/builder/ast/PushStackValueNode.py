from uel.core.builder.ast.ExpressionNode import ExpressionNode

class PushStackValueNode(ExpressionNode):
    pass