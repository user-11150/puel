# coding: UTF-8

"""
入口文件
"""

from uel.core.Main import Main
from sys import argv, stdout

if __name__ == "__main__":
    Main().main(argv)
