from uel.core.builder.ast.BinOpNode import BinOpNode

class AddNode(BinOpNode):
    pass
