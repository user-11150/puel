from uel.core.builder.ast.ExpressionNode import ExpressionNode

class CallFunctionNode(ExpressionNode):
    pass