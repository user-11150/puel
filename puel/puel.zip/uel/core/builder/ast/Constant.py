from uel.core.builder.ast.SingleNode import SingleNode

class Constant(SingleNode):
    pass
