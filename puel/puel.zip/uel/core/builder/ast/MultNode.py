from uel.core.builder.ast.BinOpNode import BinOpNode

class MultNode(BinOpNode):
    pass
