from uel.core.builder.ast.ExpressionNode import ExpressionNode

class PutNode(ExpressionNode):
    pass