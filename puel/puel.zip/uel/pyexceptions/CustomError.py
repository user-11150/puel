class CustomError(Exception):
    pass