import os

ENCODING = "UTF-8"
DEBUG = True

DIRNAME = os.path.dirname(__file__)
