from uel.bytecodefile.compress import compress
from uel.bytecodefile.compress import decompress

