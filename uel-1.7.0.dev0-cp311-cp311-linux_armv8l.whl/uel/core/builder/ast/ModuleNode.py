from uel.core.builder.ast.ContainerNode import ContainerNode


class ModuleNode(ContainerNode):
    pass
