from uel.core.builder.ast.ExpressionNode import ExpressionNode


class ReturnNode(ExpressionNode):
    pass
