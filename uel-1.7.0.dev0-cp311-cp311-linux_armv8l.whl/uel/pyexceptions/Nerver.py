class Nerver(Exception):
    pass
