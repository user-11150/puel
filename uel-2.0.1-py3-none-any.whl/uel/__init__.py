from pkg_resources import get_build_platform

__doc__ = get_build_platform()
