from uel.cli import uel_main

if __name__ == "__main__":
    uel_main()
