# It's not complete, because it based objects,
# but objects is not in progress

class UELBaseException:
    pass

class UELSyntaxError(UELException):
    pass

def uel_set_error_string(exception: UELBaseException):
    pass
