from uel.objects.typeobject import UELTypeObject
from uel.objects.object import UEObject
