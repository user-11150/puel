class UELTypeObject:
    def __init__()
