def uel_exit():
    raise SystemExit
