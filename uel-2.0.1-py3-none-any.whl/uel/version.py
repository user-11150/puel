# -*- coding: UTF-8 -*-

__version__ = "2.0.1"  # pragma: no cover
