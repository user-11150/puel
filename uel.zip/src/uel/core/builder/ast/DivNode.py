from uel.core.builder.ast.BinOpNode import BinOpNode


class DivNode(BinOpNode):
    pass
