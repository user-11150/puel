from uel.core.builder.ast.BinOpNode import BinOpNode


class MinusNode(BinOpNode):
    pass
